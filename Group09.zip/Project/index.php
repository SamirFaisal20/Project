<?php
header("location: view/mainpage.php");
?>