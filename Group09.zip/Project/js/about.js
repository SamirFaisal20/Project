$(document).ready(function()
{
    $("#abouthead").click(function()
    {
      $(".heading").toggle();
    });
});