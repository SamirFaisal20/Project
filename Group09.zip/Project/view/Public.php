
<?php 

require 'controller/check public.php';

?>
 <!DOCTYPE html>
<html>
<head>
<title>Welcome</title>
</head>
<body>


<h1 style="text-align: center;
  margin: 15% 0;">Welcome To Our Shop</h1>  	
<?php require 'fotter/Footer.php';?>

</body>
</html>
