<!DOCTYPE html>
<html lang="en">
<head>

    <title>Home Page</title>
    <link rel="stylesheet" href="../css/siteheader.css">
</head>
<body>
<div class="background">
    <h2 id="header">Welcome to Agree Bazar</h2>
</div>

</body>
</html>