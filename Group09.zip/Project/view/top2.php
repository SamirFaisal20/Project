<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/head_style.css">

</head>
<body>
<div class="right2">
	<a class="right5" href="view profile.php">View Profile</a>
	
	<a class="right5" href="Book information.php">Product information</a>
	<a class="right5" href="Change Password.php">Change Password</a><br>

</div>
</body>
</html>