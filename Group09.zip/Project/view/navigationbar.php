<!DOCTYPE html>
<html lang="en">
<head>
    <title>Home Page</title>
    <link rel="stylesheet" href="../css/navigation_style.css">
</head>
<body>
    <div class="navibox">
    <a class="navigation" href="">Admin</a> |
    <a class="navigation" href="">Seller</a>  |
    <a class="navigation" href="../view/buyer.php">Buyer</a>  |
    <a class="navigation" href="../view/deliveryman_login.php">Delivery Man</a>  
    </div>
</body>
</html>