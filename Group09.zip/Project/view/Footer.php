
<!DOCTYPE html>
<html>
<head>
<style>
.footer {
  position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   text-align: center;
   background-color: gray;
   margin-top: 30px;


}
</style>
</head>
<body>
<footer class="footer">

  	<p style="text-align: center; margin-bottom:20px;color: white;">Copyright &#169 2021</p>
</footer>
</body>
</html>