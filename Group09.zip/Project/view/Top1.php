<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/head_style.css">
<style>

</style>
</head>
<body>
	<div class="background">
<header class="grid-container," >
<div class="left4 , margin_top_10px">
	<span>Agriculture Shop</span>
</div>	
<div class="right4 , margin_top_10px">
	<?php echo "Welcome ". $_SESSION['user_name'] . " |"; ?>
	<a class="right3" href="Public.php">Home</a>
	<a  class="right3" href="contact us.php">Contact US</a>
	<a class="right3" href="Logout.php">Logout</a>

</div>
</header> 
<br>
<br>

</div>
</body>
</html>