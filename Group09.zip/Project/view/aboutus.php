<!DOCTYPE html>
<html>
<head>
    <title>About Us</title>
    <link rel="stylesheet" href="../css/aboutus.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="../js/about.js"></script>
</script>
</head>
<body>
    
    <div class="heading">
    <h3 id="abouthead"><b>About Us</b></h3>
    <div class="info">
        <span id="intro">We are the student of AIUB</span><br>
        <a href="https://www.facebook.com/PRIMESAMIR" id="link">samir Faisal</a><br>
        <a href="https://www.facebook.com/profile.php?id=100008106511380" id="link">Nasim Reza </a><br>
        <a href="https://www.facebook.com/fayaz.hemal" id="link">Hasnat Himel</a><br>
        <a href="https://www.facebook.com/wasimulbari.tanzil" id="link">Wasimul Bari Tanzil</a>
    </div>
    
    </div>
</body>
</html>