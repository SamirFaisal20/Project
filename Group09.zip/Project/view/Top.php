
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/head_style.css">
</head>
<body  >
	<div class="background">
<div class="left_name">
	<span style="margin: auto;">Agriculture Shop</span>
</div>	
<div >
</div>	
<div class="right">
	<a class="right1" href="../home.php">Chose</a>
	<a class="right1" href="Public.php">Home</a>
	<a class="right1" href="Login.php">Login</a>
	<a class="right1" href="registration.php">Sign Up</a>
	<a  class="right1" href="contact us.php">Contact US</a>
</div>
</header> 
<br>
<br>
 </div>
</body>
</html>