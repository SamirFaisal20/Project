<!DOCTYPE html>
<html>
<head>
    <title>Bodyof main page</title>
    <link rel="stylesheet" href="../css/mainpage_bod_style.css">
</head>
<body>
    <hr>
    <img class="pic"src="../view/page-2.png" alt="pic"></td>
</body>
</html>