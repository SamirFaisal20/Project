<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	*
{
	margin: 0;
	padding: 0;
}
</style>
</head>
<body >
<div style="margin: auto;text-align: center;  color: white;  background: #1376D5;width: 100%;
	height: 60px;" >
	<span style="margin-top: 10px; font-size: 35px;">Agriculture Shop</span>
</div>
</body>
</html>